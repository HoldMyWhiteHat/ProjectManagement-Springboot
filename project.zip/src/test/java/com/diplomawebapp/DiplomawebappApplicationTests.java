package com.diplomawebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiplomawebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
