package com.diplomawebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplomawebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiplomawebappApplication.class, args);
	}

}
