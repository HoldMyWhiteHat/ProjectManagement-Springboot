package com.diplomawebapp.model;

public enum Status {
    PENDING,
    REJECTED,
    ACCEPTED;
}
